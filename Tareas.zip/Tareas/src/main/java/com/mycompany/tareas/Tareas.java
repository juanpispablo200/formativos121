/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tareas;

/**
 *
 * @author Juan Pablo
 */
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

class Tarea {
    private String nombre;
    private String descripcion;

    public Tarea(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }
}

    class GestorTareas {
    private Stack<Tarea> pilaTareas;
    private Queue<Tarea> colaTareas;
    private LinkedList<Tarea> listaTareas;

    public GestorTareas() {
        pilaTareas = new Stack<>();
        colaTareas = new LinkedList<>();
        listaTareas = new LinkedList<>();
    }

    public void agregarTarea(String nombre, String descripcion) {
        Tarea tarea = new Tarea(nombre, descripcion);
        pilaTareas.push(tarea);
        colaTareas.add(tarea);
        listaTareas.add(tarea);
    }

    public void eliminarTarea(String nombre) {
        pilaTareas.removeIf(t -> t.getNombre().equals(nombre));
        colaTareas.removeIf(t -> t.getNombre().equals(nombre));
        listaTareas.removeIf(t -> t.getNombre().equals(nombre));
    }

    public void mostrarTareasPila() {
        System.out.println("Tareas pendientes en la pila:");
        for (Tarea tarea : pilaTareas) {
            System.out.println("Nombre: " + tarea.getNombre());
            System.out.println("Descripción: " + tarea.getDescripcion());
            System.out.println();
        }
    }

    public void mostrarTareasCola() {
        System.out.println("Tareas pendientes en la cola:");
        for (Tarea tarea : colaTareas) {
            System.out.println("Nombre: " + tarea.getNombre());
            System.out.println("Descripción: " + tarea.getDescripcion());
            System.out.println();
        }
    }

    public void mostrarTareasLista() {
        System.out.println("Tareas pendientes en la lista:");
        for (Tarea tarea : listaTareas) {
            System.out.println("Nombre: " + tarea.getNombre());
            System.out.println("Descripción: " + tarea.getDescripcion());
            System.out.println();
        }
    }
}


