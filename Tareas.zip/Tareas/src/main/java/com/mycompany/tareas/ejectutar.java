/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.tareas;

/**
 *
 * @author Juan Pablo
 */
public class ejectutar {

    public static void main(String[] args) {
        GestorTareas gestor = new GestorTareas();

        // Agregar tareas
        gestor.agregarTarea("Tarea 1", "Descripción de la tarea 1");
        gestor.agregarTarea("Tarea 2", "Descripción de la tarea 2");
        gestor.agregarTarea("Tarea 3", "Descripción de la tarea 3");

        // Mostrar todas las tareas
        gestor.mostrarTareasPila();
        gestor.mostrarTareasCola();
        gestor.mostrarTareasLista();

        // Eliminar una tarea
        gestor.eliminarTarea("Tarea 2");

        // Mostrar todas las tareas después de eliminar
        gestor.mostrarTareasPila();
        gestor.mostrarTareasCola();
        gestor.mostrarTareasLista();
    }
}
    
    

