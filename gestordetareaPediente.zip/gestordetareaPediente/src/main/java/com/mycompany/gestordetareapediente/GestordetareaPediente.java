/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gestordetareapediente;

/**
 *
 * @author Juan Pablo
 */
public class GestordetareaPediente {
   public static void main(String[] args) {
        // Ejemplo de uso
        Administradordetareas administradordetareas = new Administradordetareas();
        administradordetareas.gregartarea("Tarea 1", "Descripción de la tarea 1");
        administradordetareas.gregartarea("Tarea 2", "Descripción de la tarea 2");
        administradordetareas.gregartarea("Tarea 3", "Descripción de la tarea 3");
        administradordetareas.mostrarTareas();
        administradordetareas.removetarea("Tarea 2");
        administradordetareas.mostrarTarea();
    }
}
