/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gestordetareapediente;

import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Juan Pablo
 */
public class Administradordetareas {
    private List<tarea> stack; 
    private List<tarea> queue; 
    private List<tarea> linkedList; 
    
 

    public Administradordetareas() {
        stack = new ArrayList<>();
        queue = new ArrayList<>();
        linkedList = new ArrayList<>();
    }

    public void gregartarea(String nombre, String descricion) {
        tarea tarea = new tarea(nombre, descricion); 
        stack.add(tarea);
        queue.add(tarea); 
        linkedList.add(tarea); 
    }
     
        
    public void Quitartarea(String name){
           
           for ( tarea tarea : queue) {
               if (tarea.getName().equals(name)){
                   queue.remove(tarea);
                    break;
                       }
        }
                    for (tarea tarea : stack ) {
                        if (tarea.getName().equals(name)) {
                            stack.remove(tarea);
                            break;
                            
                     }
        }       
                    for (tarea tarea: linkedList) {
                       if (tarea.getName().equals(name)) {
                        linkedList.remove(tarea);
                        break;
            }
                    }

 
  
     
        }    

    void removetarea(String tarea_2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
                    
        
                          
          }
  
      

     public void mostrarTarea(){
          System.out.println("Pila de tareas pendientes:");   
          for (int i = stack.size() -1; i>=0;i--) {
              tarea tarea = stack.get(i);
              System.out.println("Nombre: " + tarea.getName());
              System.out.println("Descripción: " + tarea.getDescription());
              System.out.println();
          System.out.println("Lista enlazada de tareas pendientes:");
          for (tarea tarea : linkedList) {
            System.out.println("Nombre: " + tarea.getName());
            System.out.println("Descripción: " + tarea.getDescription());
            System.out.println();
        }
    }
          
        System.out.println("Lista enlazada de tareas pendientes:");
        for (tarea tarea : linkedList) {
            System.out.println("Nombre: " + tarea.getName());
            System.out.println("Descripción: " + tarea.getDescription());
            System.out.println();
        }
    }
          }
              
          }
      }
   